import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-delete-add',
  templateUrl: './delete-add.component.html',
  styleUrls: ['./delete-add.component.scss']
})
export class DeleteAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
